import pieqt
from pieqt import *
import mad_import

mad_import.mad_import(pieqt)
print(QTableView)
